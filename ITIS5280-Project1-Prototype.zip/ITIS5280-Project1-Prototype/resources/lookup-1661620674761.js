(function(window, undefined) {
  var dictionary = {
    "f020f744-7517-4223-9201-13000712ab1e": "AllUsersView",
    "ad0363c1-3497-445d-b4e3-d070931d208c": "ProfileInformationChatView",
    "50c7abda-9a41-4e89-bae5-58ef66fbd3f5": "CreateAccountView",
    "d2628049-991e-498d-8bc7-a780190a1441": "ForgotPasswordView",
    "f0e4d3c6-a4bb-4adb-b711-95bae522b6db": "TabView",
    "213e3a74-b901-44cf-be71-a4c80a2817ab": "ChatView",
    "7825036a-21a4-4de7-a8de-6f4ee1534f84": "AllChatroomsView",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "SigninView",
    "f7967d98-78f8-4736-8737-f70bb8886103": "ProfileInformationView",
    "695f7e08-4d67-4f1a-91f0-cb79a3552797": "NewChatView",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);