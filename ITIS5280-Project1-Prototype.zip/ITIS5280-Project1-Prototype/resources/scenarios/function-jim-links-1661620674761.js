(function(window, undefined) {

  var jimLinks = {
    "f020f744-7517-4223-9201-13000712ab1e" : {
      "Path_200" : [
        "f7967d98-78f8-4736-8737-f70bb8886103"
      ],
      "Ellipse_1" : [
        "f7967d98-78f8-4736-8737-f70bb8886103"
      ],
      "Paragraph_2" : [
        "f7967d98-78f8-4736-8737-f70bb8886103"
      ],
      "Path_3" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ]
    },
    "ad0363c1-3497-445d-b4e3-d070931d208c" : {
      "Path_2" : [
        "695f7e08-4d67-4f1a-91f0-cb79a3552797"
      ]
    },
    "50c7abda-9a41-4e89-bae5-58ef66fbd3f5" : {
      "Button_1" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ],
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "f0e4d3c6-a4bb-4adb-b711-95bae522b6db" : {
      "Path_1" : [
        "695f7e08-4d67-4f1a-91f0-cb79a3552797"
      ],
      "Paragraph_2" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_3" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Ellipse_1" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Ellipse_2" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_4" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_5" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Ellipse_3" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_6" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_7" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Panel_4" : [
        "f020f744-7517-4223-9201-13000712ab1e"
      ],
      "Path_11" : [
        "7825036a-21a4-4de7-a8de-6f4ee1534f84"
      ],
      "Paragraph_14" : [
        "7825036a-21a4-4de7-a8de-6f4ee1534f84"
      ],
      "Path_13" : [
        "f020f744-7517-4223-9201-13000712ab1e"
      ],
      "Paragraph_15" : [
        "f020f744-7517-4223-9201-13000712ab1e"
      ],
      "Path_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "213e3a74-b901-44cf-be71-a4c80a2817ab" : {
      "Paragraph_2" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_3" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_4" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_5" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_6" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_7" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_9" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_10" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_11" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_12" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_13" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Paragraph_14" : [
        "213e3a74-b901-44cf-be71-a4c80a2817ab"
      ],
      "Path_10" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ]
    },
    "7825036a-21a4-4de7-a8de-6f4ee1534f84" : {
      "Path_2" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_2" : [
        "d2628049-991e-498d-8bc7-a780190a1441"
      ],
      "Button_1" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ],
      "Button_5" : [
        "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"
      ]
    },
    "f7967d98-78f8-4736-8737-f70bb8886103" : {
      "Path_2" : [
        "f020f744-7517-4223-9201-13000712ab1e"
      ]
    },
    "695f7e08-4d67-4f1a-91f0-cb79a3552797" : {
      "Path_1" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ],
      "Button_1" : [
        "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"
      ],
      "Path_6" : [
        "f7967d98-78f8-4736-8737-f70bb8886103"
      ],
      "Ellipse_1" : [
        "ad0363c1-3497-445d-b4e3-d070931d208c"
      ],
      "Paragraph_4" : [
        "ad0363c1-3497-445d-b4e3-d070931d208c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);