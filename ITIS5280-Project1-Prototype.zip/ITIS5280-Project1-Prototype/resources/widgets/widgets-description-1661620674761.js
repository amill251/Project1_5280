	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Rectangle_16", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_200", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_200", "f020f744-7517-4223-9201-13000712ab1e"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_2", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Body large", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Body large", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Body large", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Path_3", "f020f744-7517-4223-9201-13000712ab1e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "f020f744-7517-4223-9201-13000712ab1e"]] = ["Arrow back", "s-Path_3"]; 

	widgets.descriptionMap[["s-Rectangle_16", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_1", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "ad0363c1-3497-445d-b4e3-d070931d208c"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Rectangle_16", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Input_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_10", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Input_5", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_6", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_4"]; 

	widgets.descriptionMap[["s-Input_4", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_2", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_3", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Input_6", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Radio", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_7", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Radio", "s-Group_6"]; 

	widgets.descriptionMap[["s-Button_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "50c7abda-9a41-4e89-bae5-58ef66fbd3f5"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rectangle_16", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "d2628049-991e-498d-8bc7-a780190a1441"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "d2628049-991e-498d-8bc7-a780190a1441"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_16", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Path_230", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_230", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["New home", "s-Path_230"]; 

	widgets.descriptionMap[["s-Paragraph_37", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_37", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Label medium", "s-Paragraph_37"]; 

	widgets.descriptionMap[["s-Hotspot_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Cell_35", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_35", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Rectangle_21", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Path_42", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_42", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Search", "s-Path_42"]; 

	widgets.descriptionMap[["s-Paragraph_42", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_42", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Label medium", "s-Paragraph_42"]; 

	widgets.descriptionMap[["s-Hotspot_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Cell_51", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_51", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Rectangle_26", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_26", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Path_8", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Account circle", "s-Path_8"]; 

	widgets.descriptionMap[["s-Paragraph_43", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_43", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Label medium", "s-Paragraph_43"]; 

	widgets.descriptionMap[["s-Hotspot_8", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_8", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Cell_52", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_52", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Table", "s-Table_5"]; 

	widgets.descriptionMap[["s-Panel_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Bar with labels", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Add", "s-Path_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body large", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Ellipse_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body large", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Path_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_6", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body small", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body large", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Path_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_11", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Group", "s-Path_11"]; 

	widgets.descriptionMap[["s-Paragraph_14", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body large", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Panel_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_12", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_13", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["User", "s-Path_13"]; 

	widgets.descriptionMap[["s-Paragraph_15", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Body large", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Panel_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["List", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Account circle", "s-Path_5"]; 

	widgets.descriptionMap[["s-Input_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_5"]; 

	widgets.descriptionMap[["s-Input_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_11", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Input_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Radio", "s-Group_8"]; 

	widgets.descriptionMap[["s-Input_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Radio", "s-Group_8"]; 

	widgets.descriptionMap[["s-Path_6", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Exit", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Edit", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "f0e4d3c6-a4bb-4adb-b711-95bae522b6db"]] = ["Save", "s-Path_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_5", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_6", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_7", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_8", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_8", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_2", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Account circle", "s-Path_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Path_3", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Favorite outline", "s-Path_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Path_59", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_59", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Delete", "s-Path_59"]; 

	widgets.descriptionMap[["s-Path_9", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Account circle", "s-Path_9"]; 

	widgets.descriptionMap[["s-Paragraph_6", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Path_68", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_68", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Favorite", "s-Path_68"]; 

	widgets.descriptionMap[["s-Paragraph_9", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Path_12", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Account circle", "s-Path_12"]; 

	widgets.descriptionMap[["s-Paragraph_11", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Path_13", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Favorite outline", "s-Path_13"]; 

	widgets.descriptionMap[["s-Paragraph_13", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Body small", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Input_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_15", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Path_23", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["File upload", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_10", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Arrow back", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_15", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Account circle", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "213e3a74-b901-44cf-be71-a4c80a2817ab"]] = ["Account circle", "s-Path_16"]; 

	widgets.descriptionMap[["s-Rectangle_16", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_200", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_200", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Body large", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Path_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Bookmark", "s-Path_1"]; 

	widgets.descriptionMap[["s-Panel_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_201", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_201", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_6", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_58", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_58", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Body large", "s-Paragraph_58"]; 

	widgets.descriptionMap[["s-Path_43", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_43", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Bookmark", "s-Path_43"]; 

	widgets.descriptionMap[["s-Panel_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_202", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_202", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Body large", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Path_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Bookmark", "s-Path_3"]; 

	widgets.descriptionMap[["s-Panel_4", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_4", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Ellipse_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Paragraph_4", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Body large", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Path_5", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Bookmark", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_52", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_52", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Bookmark outline", "s-Path_52"]; 

	widgets.descriptionMap[["s-Panel_5", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_5", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["List", "s-Group_51"]; 

	widgets.descriptionMap[["s-Path_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7825036a-21a4-4de7-a8de-6f4ee1534f84"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input with label", "s-Group_7"]; 

	widgets.descriptionMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input with label", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input with label", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Tonal", "s-Button_5"]; 

	widgets.descriptionMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_16", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_98", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_98", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_104", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_105", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_105", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_106", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_49", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_49", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_1", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "f7967d98-78f8-4736-8737-f70bb8886103"]] = ["Arrow back", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Arrow back", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_2", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_3", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_4", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_5", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Light bar", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Input_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Input with label", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_7", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Edit", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_265", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_265", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Group work", "s-Path_265"]; 

	widgets.descriptionMap[["s-Button_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_6", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["List", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["List", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Body large", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Body large", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Body large", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Path_197", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_197", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Add circle outline", "s-Path_197"]; 

	widgets.descriptionMap[["s-Path_85", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Clear", "s-Path_85"]; 

	widgets.descriptionMap[["s-Path_10", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Clear", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "695f7e08-4d67-4f1a-91f0-cb79a3552797"]] = ["Clear", "s-Path_11"]; 

	