var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1661620674761.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-695f7e08-4d67-4f1a-91f0-cb79a3552797" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="NewChatView" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/695f7e08-4d67-4f1a-91f0-cb79a3552797-1661620674761.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="percentage richtext manualfit firer ie-background commentable non-processed-percentage non-processed" customid="New Chatroom"   datasizewidth="100.0%" datasizeheight="50.0px" dataX="-0.0" dataY="34.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">New Chatroom</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="13.0" dataY="44.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="13.0 44.0 20.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-695f7" d="M33.0 52.75 L17.78749990463257 52.75 L24.77500009536743 45.76249980926514 L23.0 44.0 L13.0 54.0 L23.0 64.0 L24.76249995827675 62.23750004172325 L17.78749990463257 55.25 L33.0 55.25 L33.0 52.75 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-695f7" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Status bar light" datasizewidth="360.0px" datasizeheight="34.0px" dataX="0.0" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="360.0px" datasizeheight="34.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="34.0px" datasizewidthpx="360.0" datasizeheightpx="34.0" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_1_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_2" class="path firer commentable non-processed" customid="wi-fi-icone"   datasizewidth="15.0px" datasizeheight="11.9px" dataX="298.0" dataY="12.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="15.0" height="11.920103073120117" viewBox="298.0 12.000000000000012 15.0 11.920103073120117" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_2-695f7" d="M305.5064436386427 23.91365996601031 L313.0 14.577319656784374 C312.7100515462928 14.3582474836534 309.82345363361986 12.000000000000012 305.4999995775444 12.000000000000012 C301.17010330381333 12.000000000000012 298.2899484537072 14.35824738764076 298.0 14.577319656784374 L305.49355697583826 23.91365996601031 L305.50000027483617 23.92010326500825 L305.50644357383413 23.91365996601031 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-695f7" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Path_3" class="path firer commentable non-processed" customid="signal-icon"   datasizewidth="13.0px" datasizeheight="13.0px" dataX="313.0" dataY="11.0"  >\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                    	<?xml version="1.0" encoding="UTF-8"?>\
                    	<svg xmlns="http://www.w3.org/2000/svg" width="13.0" height="13.0" viewBox="313.0 11.0 13.0 13.0" preserveAspectRatio="none">\
                    	  <g>\
                    	    <defs>\
                    	      <path id="s-Path_3-695f7" d="M313.0 24.0 L326.0 24.0 L326.0 11.0 Z "></path>\
                    	    </defs>\
                    	    <g style="mix-blend-mode:normal">\
                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-695f7" fill="#FFFFFF" fill-opacity="1.0"></use>\
                    	    </g>\
                    	  </g>\
                    	</svg>\
\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="battery-icon" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Path_4" class="path firer commentable non-processed" customid="Path 80"   datasizewidth="7.0px" datasizeheight="7.7px" dataX="332.0" dataY="10.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="7.699999809265137" viewBox="332.0 10.000000000000007 7.0 7.699999809265137" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_4-695f7" d="M339.0 12.33099994659422 C339.0 11.819999933242787 338.5799997329712 11.399999999999993 338.0690000534058 11.399999999999993 L336.9 11.399999999999993 L336.9 10.000000000000007 L334.1 10.000000000000007 L334.1 11.399999999999993 L332.9309999465942 11.399999999999993 C332.4199999332428 11.399999999999993 332.0 11.819999933242787 332.0 12.33099994659422 L332.0 17.699999999999925 L339.0 17.699999999999925 L339.0 12.33099994659422 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-695f7" fill="#FFFFFF" fill-opacity="0.3"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_5" class="path firer commentable non-processed" customid="Path 81"   datasizewidth="7.0px" datasizeheight="6.3px" dataX="332.0" dataY="18.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="7.0" height="6.299999237060547" viewBox="332.0 18.0 7.0 6.299999237060547" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_5-695f7" d="M332.0 18.0 L332.0 23.369000053405628 C332.0 23.879999732971037 332.41999993324276 24.29999999999984 332.93099994659417 24.29999999999984 L338.0619998931882 24.29999999999984 C338.5799998998639 24.29999999999984 338.9999999165532 23.87999998331055 338.9999999165532 23.36899996995913 L338.9999999165532 18.0 L332.0 18.0 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-695f7" fill="#FFFFFF" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="9:30"   datasizewidth="24.9px" datasizeheight="15.0px" dataX="23.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_2_0">9:30</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="FirstName" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_1" class="text firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="309.0px" datasizeheight="59.0px" dataX="26.0" dataY="218.5" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Paragraph_3" class="richtext autofit firer commentable non-processed" customid="Chatroom Name"   datasizewidth="104.6px" datasizeheight="25.0px" dataX="38.5" dataY="206.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Chatroom Name</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_7" class="path firer commentable non-processed" customid="Edit"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="230.0" dataY="172.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="25.0" viewBox="230.0 171.9999998509883 25.0 25.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-695f7" d="M230.0 191.7923899192882 L230.0 196.99999999999991 L235.20761032209867 196.99999999999991 L250.56658829043127 181.64102141923414 L245.35897796833262 176.43341133852243 L230.0 191.7923899192882 Z M254.5938064097754 177.61380348656257 C255.1353978634082 177.072212058034 255.1353978634082 176.19733357109627 254.5938064097754 175.6557421425677 L251.34425768797857 172.40619357139633 C250.80266623434576 171.86460214286777 249.927787706855 171.86460214286777 249.3861962532222 172.40619357139633 L246.8448823564417 174.94750735038002 L252.05249267854035 180.15511743109172 L254.59380657532088 177.61380365210803 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-695f7" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_265" class="path firer commentable non-processed" customid="Group Work"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="130.0" dataY="84.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="100.0" height="100.0" viewBox="130.0 84.4999999999996 100.0 100.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_265-695f7" d="M180.0 84.4999999999996 C152.40000009536743 84.4999999999996 130.0 106.90000009536703 130.0 134.4999999999996 C130.0 162.09999990463217 152.40000009536743 184.4999999999996 180.0 184.4999999999996 C207.59999990463257 184.4999999999996 230.0 162.09999990463217 230.0 134.4999999999996 C230.0 106.90000009536703 207.60000228881836 84.4999999999996 180.0 84.4999999999996 Z M160.0 161.9999999999996 C153.10000002384186 161.9999999999996 147.5 156.39999997615774 147.5 149.4999999999996 C147.5 142.60000002384146 153.10000002384186 136.9999999999996 160.0 136.9999999999996 C166.89999997615814 136.9999999999996 172.5 142.60000002384146 172.5 149.4999999999996 C172.5 156.39999997615774 166.89999997615814 161.9999999999996 160.0 161.9999999999996 Z M167.5 114.4999999999996 C167.5 107.60000002384146 173.10000002384186 101.9999999999996 180.0 101.9999999999996 C186.89999997615814 101.9999999999996 192.5 107.60000002384146 192.5 114.4999999999996 C192.5 121.39999997615774 186.89999997615814 126.9999999999996 180.0 126.9999999999996 C173.10000002384186 126.9999999999996 167.5 121.40000057220419 167.5 114.4999999999996 Z M200.0 161.9999999999996 C193.10000002384186 161.9999999999996 187.5 156.39999997615774 187.5 149.4999999999996 C187.5 142.60000002384146 193.10000002384186 136.9999999999996 200.0 136.9999999999996 C206.89999997615814 136.9999999999996 212.5 142.60000002384146 212.5 149.4999999999996 C212.5 156.39999997615774 206.89999997615814 161.9999999999996 200.0 161.9999999999996 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_265-695f7" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Create Chatroom"   datasizewidth="160.0px" datasizeheight="40.0px" dataX="100.0" dataY="553.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Create Chatroom</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="List" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_6" class="path firer click ie-background commentable non-processed" customid="Divider"   datasizewidth="302.3px" datasizeheight="2.0px" dataX="23.2" dataY="405.3"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="302.82366943359375" height="1.5" viewBox="23.164614503088096 405.25 302.82366943359375 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_6-695f7" d="M23.914614503088096 406.0 L325.23829822275815 406.0 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-695f7" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="45.0px" datasizeheight="45.0px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="23.9" dataY="347.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0">A</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Alex Miller"   datasizewidth="257.0px" datasizeheight="68.0px" dataX="68.9" dataY="338.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Alex Miller</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_8" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="302.3px" datasizeheight="2.0px" dataX="22.6" dataY="473.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="302.82366943359375" height="1.5" viewBox="22.588158140165394 473.5 302.82366943359375 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-695f7" d="M23.338158140165394 474.25 L324.6618418598354 474.25 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-695f7" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="45.0px" datasizeheight="45.0px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="23.3" dataY="415.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0">T</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Tom Va"   datasizewidth="257.0px" datasizeheight="68.0px" dataX="68.3" dataY="406.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Tom Va</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_9" class="path firer ie-background commentable non-processed" customid="Divider"   datasizewidth="302.3px" datasizeheight="2.0px" dataX="22.3" dataY="541.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="302.82366943359375" height="1.5" viewBox="22.250000000000487 541.5000000000005 302.82366943359375 1.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-695f7" d="M23.000000000000487 542.2500000000005 L324.32368371967056 542.2500000000005 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-695f7" fill="none" stroke-width="0.5" stroke="#79747E" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_3" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="45.0px" datasizeheight="45.0px" datasizewidthpx="45.0" datasizeheightpx="45.0" dataX="23.0" dataY="483.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_3)">\
                            <ellipse id="s-Ellipse_3" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse" cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                            <ellipse cx="22.5" cy="22.5" rx="22.5" ry="22.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_3" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_3_0">J</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Jared Tamulynas"   datasizewidth="257.0px" datasizeheight="68.0px" dataX="68.0" dataY="474.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Jared Tamulynas</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="percentage richtext manualfit firer ie-background commentable non-processed-percentage non-processed" customid="Add Users"   datasizewidth="100.0%" datasizeheight="40.0px" dataX="0.0" dataY="287.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Add Users</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_197" class="path firer click commentable non-processed" customid="Add Circle Outline"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="291.0" dataY="364.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="20.0" viewBox="291.0 364.0 20.0 20.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_197-695f7" d="M302.0 369.0 L300.0 369.0 L300.0 373.0 L296.0 373.0 L296.0 375.0 L300.0 375.0 L300.0 379.0 L302.0 379.0 L302.0 375.0 L306.0 375.0 L306.0 373.0 L302.0 373.0 L302.0 369.0 Z M301.0 364.0 C295.4800000190735 364.0 291.0 368.4800000190735 291.0 374.0 C291.0 379.5199999809265 295.4800000190735 384.0 301.0 384.0 C306.5199999809265 384.0 311.0 379.5199999809265 311.0 374.0 C311.0 368.4800000190735 306.5200004577637 364.0 301.0 364.0 Z M301.0 382.0 C296.5900001525879 382.0 293.0 378.4100000858307 293.0 374.0 C293.0 369.5899999141693 296.5899999141693 366.0 301.0 366.0 C305.4100000858307 366.0 309.0 369.5899999141693 309.0 374.0 C309.0 378.4100000858307 305.4100000858307 382.0 301.0 382.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_197-695f7" fill="#673FB4" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_85" class="path firer commentable non-processed" customid="Clear"   datasizewidth="14.0px" datasizeheight="14.0px" dataX="294.0" dataY="435.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="14.0" viewBox="294.0000000000002 435.50000000000006 14.0 14.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_85-695f7" d="M308.0000000000002 436.90999984741217 L306.5900001525881 435.50000000000006 L301.0000000000002 441.09000015258795 L295.40999984741234 435.50000000000006 L294.0000000000002 436.90999984741217 L299.5900001525881 442.50000000000006 L294.0000000000002 448.09000015258795 L295.40999984741234 449.50000000000006 L301.0000000000002 443.90999984741217 L306.5900001525881 449.50000000000006 L308.0000000000002 448.09000015258795 L302.40999984741234 442.50000000000006 L308.0000000000002 436.90999984741217 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_85-695f7" fill="#673FB4" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_10" class="path firer commentable non-processed" customid="Clear"   datasizewidth="14.0px" datasizeheight="14.0px" dataX="294.0" dataY="503.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="14.0" viewBox="294.0000000000002 503.50000000000017 14.0 14.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_10-695f7" d="M308.0000000000002 504.9099998474123 L306.5900001525881 503.50000000000017 L301.0000000000002 509.09000015258806 L295.40999984741234 503.50000000000017 L294.0000000000002 504.9099998474123 L299.5900001525881 510.50000000000017 L294.0000000000002 516.0900001525881 L295.40999984741234 517.5000000000002 L301.0000000000002 511.9099998474123 L306.5900001525881 517.5000000000002 L308.0000000000002 516.0900001525881 L302.40999984741234 510.50000000000017 L308.0000000000002 504.9099998474123 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-695f7" fill="#673FB4" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_11" class="path firer commentable hidden non-processed" customid="Clear"   datasizewidth="14.0px" datasizeheight="14.0px" dataX="294.0" dataY="367.3"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="14.0" height="14.0" viewBox="294.0000000000004 367.2500000000001 14.0 14.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_11-695f7" d="M308.0000000000004 368.6599998474122 L306.5900001525883 367.2500000000001 L301.0000000000004 372.840000152588 L295.4099998474125 367.2500000000001 L294.0000000000004 368.6599998474122 L299.5900001525883 374.2500000000001 L294.0000000000004 379.840000152588 L295.4099998474125 381.2500000000001 L301.0000000000004 375.6599998474122 L306.5900001525883 381.2500000000001 L308.0000000000004 379.840000152588 L302.4099998474125 374.2500000000001 L308.0000000000004 368.6599998474122 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-695f7" fill="#673FB4" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;